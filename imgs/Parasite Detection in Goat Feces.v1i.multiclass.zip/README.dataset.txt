# Parasite Detection in Goat Feces > 2024-04-03 4:34pm
https://universe.roboflow.com/eggsbythedozen-ygujs/parasite-detection-in-goat-feces

Provided by a Roboflow user
License: CC BY 4.0

